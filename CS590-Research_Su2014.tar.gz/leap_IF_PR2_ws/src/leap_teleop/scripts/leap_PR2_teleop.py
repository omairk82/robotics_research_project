#!/usr/bin/env python

################################################################################
# USC Directed Research - Summer 2014                                          #
# M. Omair Khan (SID - 9171668996)                                             #
# August 12, 2014                                                              #
# LeapMotion-based teleoperations contoller for ROS PR2 Simulator              #
################################################################################

import Leap, sys, thread, time, math
from Leap import CircleGesture, KeyTapGesture, ScreenTapGesture, SwipeGesture
import rospy
from geometry_msgs.msg import Twist

#### global variables - start ####
global LINEAR_SPEED_RANGE, ANGULAR_SPEED_RANGE, LI, NEAR_SPEED_STEP, ANGULAR_SPEED_STEP, RANGE_STEP
global TURN_YAW_RANGE_MIN, LINEAR_STOP_SPHERE_RADIUS_MAX, DIRECTION_PITCH_CHANGE
global PREV_HAND_PITCH, PREV_LIN_X, PREV_LIN_X_DIRECTION, PREV_ANG_Z
global ROS_TWIST, ROS_NODE
# - differential drive ranges -
LINEAR_SPEED_RANGE = [-0.2, 0.2] #[min linear speed, max linear speed]
ANGULAR_SPEED_RANGE = [-1.0, 1.0] #[min angular speed, max angular speed]
LINEAR_SPEED_STEP = 0.02 #fixed linear speed step size
ANGULAR_SPEED_STEP = 0.1 #fixed angular speed step size
RANGE_STEP = 0.1 #%fixed percentage step for linear and angular speed min/max range increases/decreases
# - leap motion indicator ranges for PR2 simulator -
TURN_YAW_RANGE_MIN = 40 #min hand yaw value for leap motion turn indication
LINEAR_STOP_SPHERE_RADIUS_MAX = 40 #max hand sphere radius for leap motion stop indication
#DIRECTION_PITCH_CHANGE = 0.35 #percentage of hand pitch change to indicate leap motion directionality indication
DIRECTION_PITCH = [-10, 50] #[max for neg. pitch/speed decrease, min for pos. pitch, speed increase]
NO_HANDS_LIM = 75; #limit for sequential no hands frames before full stop invoked
COOL_OFF_SPEED_UPDATE = 10 #number of frames required to pass between velocity range updates
COOL_OFF_DIRECTION_UPDATE = 5 #number of frames required to pass between velocity range updates
SPEED_ROLL_MIN = 70 #minimum absolute value of either hand's roll value to indicate speed change
# - topic parameter tracking -
PREV_HAND_PITCH = [0,0] #two previous hands average pitch values, [second most previous, previous], 
PREV_LIN_X = 0 #previous Twist liner.x value
PREV_LIN_X_DIRECTION = 1 #previous Twist linear.x velocity direction
PREV_ANG_Z = 0 #previous Twist angular.z value
# - ROS variables for PR2 simulator -
ROS_TWIST = "/base_controller/command" #geometry_msgs/Twist topic for controlling PR2
ROS_NODE = "leap_teleop" #node name for leap motion based teleop publisher
#### global variables - end ####

#### class declaration - start ####
class LeapTeleopPub(Leap.Listener):
    finger_names = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky']
    bone_names = ['Metacarpal', 'Proximal', 'Intermediate', 'Distal']
    state_names = ['STATE_INVALID', 'STATE_START', 'STATE_UPDATE', 'STATE_END']
    
    global NO_HANDS_LIM
    no_hands_cntr = 0; #counter for frames with no hands
    frame_speed_cool_off_cntr = 0; #counter in between speed range updates
    frame_direction_cool_off_cntr = 0; #counter in between directionality updates

    def on_init(self, controller):
        global ROS_TWIST
        print "Initialized"
        rospy.on_shutdown(self.cleanup) # register this function to be called on shutdown
        
        # publish to cmd_vel
        self.pub = rospy.Publisher(ROS_TWIST, Twist)
        # give our node/publisher a bit of time to connect
        rospy.sleep(1)
    
    def cleanup(self):
        # stop the robot on rospy shutdown
        twist = Twist()
        self.pub.publish(twist)
    
    def on_connect(self, controller):
        print "Connected"

    def on_disconnect(self, controller):
        # Note: not dispatched when running in a debugger.
        print "Disconnected"

    def on_exit(self, controller):
        print "Exited"

    def on_frame(self, controller):
        # Get the most recent frame and report some basic information
        frame = controller.frame()
        
        if not (frame.hands.is_empty):
        
            #print "Frame id: %d, timestamp: %d, hands: %d, fingers: %d, tools: %d "% (
            #      frame.id, frame.timestamp, len(frame.hands), len(frame.fingers), len(frame.tools) )
            
            #self.print_DN_vals(frame)
            self.generate_actions(frame, debug=False)
        
        else:
            self.no_hands_cntr += 1
            if self.no_hands_cntr >= NO_HANDS_LIM:
                #print "Frame id: %d, timestamp: %d, hands: %d, fingers: %d, tools: %d "% (
                #    frame.id, frame.timestamp, len(frame.hands), len(frame.fingers), len(frame.tools) )
                print "No hands found for %d consecutive frames - invoking abrupt stop!" % NO_HANDS_LIM
                self.full_stop(frame, debug=False)
                self.no_hands_cntr = 0 #reset counter
            #end if
        #end if
        
        #increment speed and direction cool off counters
        self.frame_speed_cool_off_cntr += 1
        self.frame_direction_cool_off_cntr += 1
        
    #end def
    
    def print_DN_vals(self, frame): #debugging tool to check leap motion raw values
        # Get hands data
        for hand in frame.hands:

            handType = "Left hand" if hand.is_left else "Right hand"

            print "\t%s, id %d, position: %s" % (
                handType, hand.id, hand.palm_position)

            # Get the hand's normal vector and direction
            normal = hand.palm_normal
            direction = hand.direction

            # Calculate the hand's pitch, roll, and yaw angles
            print "\t\tpitch: %f degrees, roll: %f degrees, yaw: %f degrees" % (
                direction.pitch * Leap.RAD_TO_DEG,
                normal.roll * Leap.RAD_TO_DEG,
                direction.yaw * Leap.RAD_TO_DEG)
            
            # Get the hand's sphere radius and palm position
            print "\t\tHand sphere radius: %f mm, palm position: %s" % (
                hand.sphere_radius, hand.palm_position)
            
        #end for
    #end def
    
    def full_stop(self, frame, debug=True):
        #if hands are not found, bring robot to an abrupt and full stop
        global PREV_HAND_PITCH, PREV_LIN_X, PREV_LIN_X_DIRECTION, PREV_ANG_Z
        
        if debug: print "Frame id: %d, timestamp: %d, hands: %d, fingers: %d, tools: %d "% (
                        frame.id, frame.timestamp, len(frame.hands), len(frame.fingers), len(frame.tools) )
        else: print "Frame id: %d" % (frame.id)
        
        params = ["linear.x","angular.z"] #initialize topic parameters
        values = [0,0] #initialize topic values [linear, rotation]
        #publish values to ROS
        self.publish_data(ROS_TWIST, params, values)
        #reset all globals, except for velocity direction
        REV_HAND_PITCH = [0,0]
        PREV_LIN_X = 0
        PREV_ANG_Z = 0
    #end def
    
    def generate_actions(self, frame, debug=True):
        global LINEAR_SPEED_RANGE, ANGULAR_SPEED_RANGE, LI, NEAR_SPEED_STEP, ANGULAR_SPEED_STEP, RANGE_STEP
        global TURN_YAW_RANGE_MIN, LINEAR_STOP_SPHERE_RADIUS_MAX, DIRECTION_PITCH, COOL_OFF_SPEED_UPDATE
        global PREV_HAND_PITCH, PREV_LIN_X, PREV_LIN_X_DIRECTION, PREV_ANG_Z
        global ROS_TWIST, ROS_NODE
        
        def round_step(curr_val, lim_val, step_val):
            #function for determining if step_val goes beyond lim_val, if so only return the step_val
            if float(lim_val) >= 0 and float(curr_val) + float(step_val) < float(lim_val): #check if within limits after applying step_val 
                return float(curr_val) + float(step_val)
            elif float(lim_val) <= 0 and float(curr_val) - float(step_val) > float(lim_val): #check if within limits after applying step_val
                return float(curr_val) - float(step_val) 
            else: #beyond lim_val, so round to lim_val
                return lim_val
            #end if
        #end def
        
        frame_ang_step = [0,0] #[L, R] hand angular steps for this frame, default is no rotation
        frame_lin_step = [0,0] #[L, R] hand linear steps for this frame, default is no linear move
        frame_pitch = [0,0] #[L,R] hand pitch values for this frame, default is zero pitch
        frame_roll = [0,0] #[L,R] hand roll values for this frame, default is zero roll
        
        if debug: print "Frame id: %d, timestamp: %d, hands: %d, fingers: %d, tools: %d "% (
                        frame.id, frame.timestamp, len(frame.hands), len(frame.fingers), len(frame.tools) )
        
        else: print "Frame id: %d" % (frame.id)
        
        # Get hands data
        for hand in frame.hands:

            handType = "Left hand" if hand.is_left else "Right hand"

            if debug: print "\t%s, id %d, position: %s" % (
                handType, hand.id, hand.palm_position)

            # Get the hand's normal vector and direction
            normal = hand.palm_normal
            direction = hand.direction

            # Calculate the hand's pitch, roll, and yaw angles
            if debug: print "\t\tpitch: %f degrees, roll: %f degrees, yaw: %f degrees" % (
                direction.pitch * Leap.RAD_TO_DEG,
                normal.roll * Leap.RAD_TO_DEG,
                direction.yaw * Leap.RAD_TO_DEG)
            
            pitch = direction.pitch * Leap.RAD_TO_DEG
            roll = normal.roll * Leap.RAD_TO_DEG
            yaw = direction.yaw * Leap.RAD_TO_DEG
            
            # Get the hand's sphere radius and palm position
            if debug: print "\t\tHand sphere radius: %f mm, palm position: %s" % (
                hand.sphere_radius, hand.palm_position)
            
            rad = hand.sphere_radius
            
            #record angular moves
            if handType == "Left hand": #clockwise rotation
                if PREV_ANG_Z > ANGULAR_SPEED_RANGE[0]: #only active if not at min ang speed limit
                    if yaw >= TURN_YAW_RANGE_MIN: #left hand positive yaw values rotate robot clockwise
                        frame_ang_step[0] = ANGULAR_SPEED_STEP; #record that left hand wants to rotate
                    #end if
                #end if
            else: #Right hand, counter clockwise rotation
                if PREV_ANG_Z < ANGULAR_SPEED_RANGE[1]: #only active if not at max ang speed limit
                    if yaw <= -1*TURN_YAW_RANGE_MIN: #right hand negative yaw values rotate robot counter clockwise
                        frame_ang_step[1] = -1*ANGULAR_SPEED_STEP; #record that lright hand wants to rotate
                    #end if
                #end if
            #end if
            
            #record linear moves
            if handType == "Left hand": #clockwise rotation
                if rad > LINEAR_STOP_SPHERE_RADIUS_MAX: #only active if hand sphere radius is big enough
                    frame_lin_step[0] = LINEAR_SPEED_STEP; #record that left hand wants to rotate
                #end if
            else: #Right hand, counter clockwise rotation
                if rad > LINEAR_STOP_SPHERE_RADIUS_MAX: #only active if hand sphere radius is big enough
                    frame_lin_step[1] = LINEAR_SPEED_STEP; #record that left hand wants to rotate
                #end if
            #end if
            
            #record velocity direction moves (e.g. record hand pitch values
            if handType == "Left hand":
                frame_pitch[0] = pitch
            else:
                frame_pitch[1] = pitch
            #end if
            
            #record speed alteration moves (e.g. record hand roll values)
            if handType == "Left hand":
                frame_roll[0] = roll
            else:
                frame_roll[1] = roll
            #end if            
            
        #end for
        
        #determine final resolutions after data recorded for both hands
        params = ["twist.linear.x","twist.angular.z"] #initialize topic parameters
        values = [0,0] #initialize topic values [linear, rotation]
        #resolve angular moves
        if frame_ang_step == [0,0] or abs(frame_ang_step[0]) == abs(frame_ang_step[1]):
            #no rotation or opposite rotations recorded, work rotation back to zero
            if PREV_ANG_Z < 0: #increase by fixed angular step size to bring back to zero
                values[1] = round_step(PREV_ANG_Z, 0, ANGULAR_SPEED_STEP)
            elif PREV_ANG_Z > 0: #decrease by fixed angular step size to bring back to zero
                values[1] = round_step(PREV_ANG_Z, 0, ANGULAR_SPEED_STEP)
            #end if
        elif frame_ang_step[0] != 0: #left rotation = clockwise (increase rotation)
            values[1] = round_step(PREV_ANG_Z, ANGULAR_SPEED_RANGE[1], ANGULAR_SPEED_STEP)
        elif frame_ang_step[1] !=0: # right rotation = counter clockwise (decrease rotation)
            values[1] = round_step(PREV_ANG_Z, ANGULAR_SPEED_RANGE[0], ANGULAR_SPEED_STEP)
        #end if
        PREV_ANG_Z = values[1] #update previous value for angular speed
        
        #resolve linear moves
        if frame_lin_step != [0,0] and abs(frame_lin_step[0]) == abs(frame_lin_step[1]):
            #linear motion recorded, move in current direction
            if PREV_LIN_X_DIRECTION < 0: #move in reverse by fixed linear step size
                values[0] = round_step(PREV_LIN_X, LINEAR_SPEED_RANGE[0], LINEAR_SPEED_STEP)
            else: #move forward by fixed linear step size
                values[0] = round_step(PREV_LIN_X, LINEAR_SPEED_RANGE[1], LINEAR_SPEED_STEP)
            #end if
        else: #no linear motion recorded, work linear motion back to zero
            if PREV_LIN_X != 0: #move by fixed linear step size to bring back to zero
                values[0] = round_step(PREV_LIN_X, 0, LINEAR_SPEED_STEP)
            #end if
        #end if
        PREV_LIN_X = values[0] #update previous value for linear speed
        
        #resolve velocity direction moves
        def average(input_list): #return average of the list as a float
            return float(sum(input_list)) / float(len(input_list))
        #end def
        
        if self.frame_direction_cool_off_cntr > COOL_OFF_DIRECTION_UPDATE: #must wait required number of frames from last speed update
            #if average(frame_pitch) > (average(PREV_HAND_PITCH))*(1 + DIRECTION_PITCH_CHANGE): #forward motion detected
            if max(frame_pitch) >= DIRECTION_PITCH[1]:
                #print "DIRECTION UPDATE = FORWARD"
                PREV_LIN_X_DIRECTION = 1
            elif min(frame_pitch) <= DIRECTION_PITCH[0]:
                #print "DIRECTION UPDATE = REVERSE"
                PREV_LIN_X_DIRECTION = -1
            #end if
            
            self.frame_direction_cool_off_cntr = 0 #reset directionality cool off counter
        #end if
        
        #resolve speed alteration moves
        if self.frame_speed_cool_off_cntr > COOL_OFF_SPEED_UPDATE: #must wait required number of frames from last speed update
            if abs(frame_roll[0]) >= SPEED_ROLL_MIN: #left hand roll change indicates speed decrease by fixed percentage
                #print "\tDECREASE SPEED by %2.2f" % (float(RANGE_STEP)*100.)
                LINEAR_SPEED_RANGE = [float(LINEAR_SPEED_RANGE[0])*float((1-RANGE_STEP)), float(LINEAR_SPEED_RANGE[1])*float((1-RANGE_STEP))]
                ANGULAR_SPEED_RANGE = [float(ANGULAR_SPEED_RANGE[0])*float((1-RANGE_STEP)), float(ANGULAR_SPEED_RANGE[1])*float((1-RANGE_STEP))]
                #print "\tLINEAR SPEED RANGE = [%2.2f, %2.2f]" % (LINEAR_SPEED_RANGE[0], LINEAR_SPEED_RANGE[1])
                #print "\tANGULAR SPEED RANGE = [%2.2f, %2.2f]" % (ANGULAR_SPEED_RANGE[0], ANGULAR_SPEED_RANGE[1])
            elif abs(frame_roll[1]) >= SPEED_ROLL_MIN: #right hand roll change indicates speed increase by fixed percentage
                #print "\tINCREASE SPEED by %2.2f" % (float(RANGE_STEP)*100.)
                LINEAR_SPEED_RANGE = [float(LINEAR_SPEED_RANGE[0])*float((1+RANGE_STEP)), float(LINEAR_SPEED_RANGE[1])*float((1+RANGE_STEP))]
                ANGULAR_SPEED_RANGE = [float(ANGULAR_SPEED_RANGE[0])*float((1+RANGE_STEP)), float(ANGULAR_SPEED_RANGE[1])*float((1+RANGE_STEP))]
                #print "\tLINEAR SPEED RANGE = [%2.2f, %2.2f]" % (LINEAR_SPEED_RANGE[0], LINEAR_SPEED_RANGE[1])
                #print "\tANGULAR SPEED RANGE = [%2.2f, %2.2f]" % (ANGULAR_SPEED_RANGE[0], ANGULAR_SPEED_RANGE[1])
            #end if
            
            self.frame_speed_cool_off_cntr = 0 #reset speed cool off counter
        #end if
        
        #publish values to ROS
        self.publish_data(ROS_TWIST, params, values)
        
    #end def
          
    def publish_data(self, topic_name, topic_params, topic_values):
        global LINEAR_SPEED_RANGE, ANGULAR_SPEED_RANGE
        
        #create a Twist message
        twist = Twist()
        
        #Publishes topic data to ROS
        print "\t" + topic_name
        for i in range(len(topic_params)):
            print "\t" + str(topic_params[i]) + " = " + str(topic_values[i])
        #end for
        
        twist.linear.x = topic_values[0]
        twist.angular.z = topic_values[1]
        self.pub.publish(twist)
        #r.sleep()
        
        if PREV_LIN_X_DIRECTION == 1:
            print "\tDIRECTION = FORWARD (+x)"
        else:
            print "\tDIRECTION = REVERSE (-x)"
        #end if
        print "\tLINEAR SPEED RANGE = [%2.2f, %2.2f]" % (LINEAR_SPEED_RANGE[0], LINEAR_SPEED_RANGE[1])
        print "\tANGULAR SPEED RANGE = [%2.2f, %2.2f]" % (ANGULAR_SPEED_RANGE[0], ANGULAR_SPEED_RANGE[1])
        
    #end def
#end class Leap_Teleop_Pub

#### class declaration - end ####

#### function declaration - start ####

#### function declaration - end ####

#### MAIN ####
def main():
    # Create ROS node
    rospy.init_node(ROS_NODE)
    
    # Create a leap motion listener
    leap_teleop = LeapTeleopPub()
    controller = Leap.Controller()

    # Have the sample listener receive events from the controller
    controller.add_listener(leap_teleop)

    # Keep this process running until Enter is pressed
    print "Press Enter to quit..."
    try:
        sys.stdin.readline()
    except KeyboardInterrupt:
        pass
    finally:
        # Remove the sample listener when done
        controller.remove_listener(leap_teleop)


if __name__ == "__main__":
    main()
